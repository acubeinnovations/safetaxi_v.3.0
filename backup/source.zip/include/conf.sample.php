<?php
// prevent execution of this page by direct call by browser
if ( !defined('CHECK_INCLUDED') ){
    exit();
}

// Mysql Configuration Constants

define('MYSQL_USERNAME', '');
define('MYSQL_PASSWORD', '');
define('MYSQL_HOST', '');
define('MYSQL_DB_NAME', '');

?>
