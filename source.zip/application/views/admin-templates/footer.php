		  </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->       
		
        <!-- Bootstrap -->
        <script src="<?php echo base_url();?>js/bootstrap.min.js" type="text/javascript"></script>
        <!-- Morris.js charts -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        
        <!-- Sparkline -->
        <script src="<?php echo base_url();?>js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- jvectormap -->
        <script src="<?php echo base_url();?>js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
        <!-- fullCalendar -->
        <script src="<?php echo base_url();?>js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
        <!-- jQuery Knob Chart -->
        <script src="<?php echo base_url();?>js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <!-- daterangepicker -->
        <script src="<?php echo base_url();?>js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="<?php echo base_url();?>js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url();?>js/AdminLTE/app.js" type="text/javascript"></script>
       
       
        
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url();?>js/AdminLTE/demo.js" type="text/javascript"></script>
		
		<script src="<?php echo base_url();?>plugins/datetimepicker-master/jquery.datetimepicker.js"></script>
		<!-- InputMask -->
        <script src="<?php echo base_url();?>js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>js/plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
		
		<!--editable_dropdown.js -->
        <script src="<?php echo base_url();?>js/editable_dropdown.js" type="text/javascript"></script>
		<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization',
       'version':'1','packages':['timeline']}]}"></script>
		

		 <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&libraries=places&language=en-AU"></script>
      	<!--main.js -->
        <script src="<?php echo base_url();?>js/main.js" type="text/javascript"></script>

    </body>
</html>
